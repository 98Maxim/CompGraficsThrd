#pragma once
#include <vector>

polygon^ Pclip(polygon^ P, point Pmin, point Pmax);